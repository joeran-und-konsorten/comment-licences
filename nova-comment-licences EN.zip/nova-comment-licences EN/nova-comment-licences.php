<?php
/**
 * Plugin Name: Comments with CC licenses
 * Description: Let your visitors attribute a CC (Creative Commons) license of their choice for every comment they leave.
 * Author: nova GmbH // J&K – Jöran und Konsorten GmbH & Co. KG // OERcamp
 * Version: 1.0.0
    License: GPLv3
    License URL: https://www.gnu.org/licenses/gpl-3.0.html

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

wp_enqueue_style( 'nova-comment-licences-style', plugin_dir_url( __FILE__ ) . '/style.css');

//Modify Comment-Content: Add Custom Field Values according licence
add_filter('get_comment_date', 'add_licence', 10, 3);

function add_licence($date, $d, $comment){
  
  if(get_field('license', $comment)){
  
    $licence_val = get_field('license', $comment)['value'];
    $licence_label = get_field('license', $comment)['label'];

    if($licence_val != 'none'):

      $licence_url = 'https://creativecommons.org/licenses/';

      switch ( $licence_val ) {
        case 'ccby':
            $p = 'by/4.0';
            break;
        case 'ccbysa':
            $p = 'by-sa/4.0'; 
            break;
        case 'ccbynd':
            $p = 'by-nd/4.0';
            break;
        case 'ccbync':
            $p = 'by-nc/4.0';
            break;
        case 'ccbyncsa':
            $p = 'by-nc-sa/4.0';
            break;
        case 'ccbyncnd':
            $p = 'by-nc-nd/4.0';
            break;
        case 'cc0':
            $p = 'zero/1.0';
            break;
      }
    
      $licence_url .=  $p.'/deed.de';

    

    $licence_content = '<br><p class="licencetext">'; 
    $licence_content .= '<a rel="license" target="_blank" href="'.$licence_url.'">';
    $licence_content .= '<img alt="Creative Commons License"" class="licenceimg" src="'.plugin_dir_url( __FILE__ ).'img/'.$licence_val.'.png">';
    $licence_content .= '</a>';
    $licence_content .= 'This comment '; 
    if($comment->comment_author){
      $licence_content .= 'by ';
      if($comment->comment_author_url){
        $licence_content .= '<a target="_blank" href="'.$comment->comment_author_url.'">';
      }
      $licence_content .= $comment->comment_author;
  
      if($comment->comment_author_url){
        $licence_content .= '</a>';
      }
    }
    $licence_content .= ' is licensed under ';
    $licence_content .= '<a rel="license" target="_blank" href="'.$licence_url.'">';
    $licence_content .= $licence_label;
    $licence_content .= '</a>';

/*Enter an URL with your own background information here*/

    $licence_content .= '. (<a href="www.please-fill-in-an-adress-with-more-information.here">Background</a>)</p>'; 

    else:
      $licence_content = '<br><p class="licencetext">'; 
      $licence_content .= 'This comment ';
      
      if($comment->comment_author){
        $licence_content .= 'by ';
        if($comment->comment_author_url){
          $licence_content .= '<a target="_blank" href="'.$comment->comment_author_url.'">';
        }
        $licence_content .= $comment->comment_author;
    
        if($comment->comment_author_url){
          $licence_content .= '</a>';
        }
      }
/*Enter an URL with your own background information here*/

      $licence_content .= ' does not have a CC license. (<a href="www.please-fill-in-an-adress-with-more-information.here">Background</a>)';

    endif;
   
    $comment->comment_content = $comment->comment_content.$licence_content;
  }
  
}


//register field group
if( function_exists('acf_add_local_field_group') ):

  acf_add_local_field_group(array(
    'key' => 'group_5caf43d0392fe',
    'title' => 'License for Comment',
    'fields' => array(
      array(
        'key' => 'field_5caf43e6759d6',
        'label' => 'license',
        'name' => 'license',
        'type' => 'select',
        'instructions' => 'Choose a CC license for your comment. (<a href="www.please-fill-in-an-adress-with-more-information.here">Background</a>)', /*Enter an URL with your own background information here*/
        'required' => 0,
        'conditional_logic' => 0,
        'wrapper' => array(
          'width' => '',
          'class' => '',
          'id' => '',
        ),
        'choices' => array(
          'ccby' => 'CC BY 4.0',
          'ccbysa' => 'CC BY-SA 4.0',
          'ccbynd' => 'CC BY-ND 4.0',
          'ccbync' => 'CC BY-NC 4.0',
          'ccbyncsa' => 'CC BY-NC-SA 4.0',
          'ccbyncnd' => 'CC BY-NC-ND 4.0',
          'cc0' => 'CC0 (CC Zero)',
          'none' => ' not under a CC license',
        ),
        'default_value' => array(
        ),
        'allow_null' => 0,
        'multiple' => 0,
        'ui' => 0,
        'return_format' => 'array',
        'ajax' => 0,
        'placeholder' => '',
      ),
    ),
    'location' => array(
      array(
        array(
          'param' => 'comment',
          'operator' => '==',
          'value' => 'all',
        ),
      ),
    ),
    'menu_order' => 0,
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
    'hide_on_screen' => '',
    'active' => true,
    'description' => '',
  ));
  
  endif;